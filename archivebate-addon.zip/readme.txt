Webcam-Profil Archivator
New Features in Version 1.5

Improvements

Dynamic URL detection
Support for additional subdomains (e.g., de.chaturbate.com, de.bongacams.com)
Exclusion of category pages
Extended popup menu with settings
Enhanced domain detection for all supported platforms
Supported Platforms

Chaturbate (including all subdomains such as de.chaturbate.com)
Stripchat (including stripchat.global)
XHamsterLive
Bongacams (including all subdomains such as de.bongacams.com)
Features

Enable/disable the addon
Activate/deactivate individual platforms
Add custom URLs
Quick profile search on Archivebate
Installation

Extract the extension files
Open Chrome and go to chrome://extensions/
Enable "Developer mode"
Click "Load unpacked extension"
Select the extension folder

Known Limitations


Exclusion of category pages (e.g., female-cams, couples, etc.)
Only profiles with direct username paths are supported
Currently only available in German


Troubleshooting
If issues occur:

Check if platform toggles are enabled
Ensure the profile path is direct
Update the extension after changes
Verify the website is in the correct format
Privacy
This extension does not collect personal data.

Technical Notes

The extension uses endsWith() for domain detection to improve subdomain support.
Custom URLs are fully supported.
All supported sites use the same logic to extract usernames from URLs.