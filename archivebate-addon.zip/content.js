(function() {
  // Angepasste Konfiguration
  const siteConfigs = [
    {
      hostname: 'chaturbate.com',
      usernameIndex: 1,
      excludePatterns: ['/female-cams', '/male-cams', '/couple-cams', '/trans-cams']
    },
    {
      hostname: 'xhamsterlive.com',
      usernameIndex: 1,
      excludePatterns: ['/couples', '/men', '/trans']
    },
    {
      hostname: 'stripchat.com',
      usernameIndex: 1,
      excludePatterns: [] // Keine Ausschlüsse für stripchat.com
    },
    {
      hostname: 'stripchat.global',
      usernameIndex: 1,
      excludePatterns: ['/couples', '/men', '/trans']
    },
    {
      hostname: 'bongacams.com',
      usernameIndex: 1,
      excludePatterns: ['/female', '/male', '/couple', '/trans']
    }
  ];

  // Bestehende Funktion, um zu prüfen, ob der Button angezeigt werden soll
  function shouldShowButton(currentConfig, path) {
    return !currentConfig.excludePatterns.some(pattern => path.includes(pattern));
  }

  // Überprüfung, ob sich die URL ändert
  function observeUrlChanges() {
    let lastUrl = window.location.href;
    
    const observer = new MutationObserver(() => {
      const currentUrl = window.location.href;
      if (currentUrl !== lastUrl) {
        lastUrl = currentUrl;
        removeExistingButton();
        checkAndAddButton();
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  // Entfernt einen bestehenden Button, falls vorhanden
  function removeExistingButton() {
    const existingButton = document.getElementById('archivebate-button');
    if (existingButton) {
      existingButton.remove();
    }
  }

  function checkAndAddButton() {
    chrome.storage.sync.get(
      ['addonEnabled', 'chaturbateEnabled', 'stripchatEnabled', 'xhamsterEnabled', 'bongacamsEnabled', 'customUrls'],
      function(settings) {
        // Wenn das Addon ausgeschaltet ist, nicht weitermachen
        if (!settings.addonEnabled) return;

        const currentHostname = window.location.hostname.replace('www.', '');
        const path = window.location.pathname;
        const pathParts = path.split('/').filter(Boolean);
        
        // Suche in der vordefinierten Konfiguration
        // Verbesserte Domain-Erkennung für Subdomains
        let currentConfig = null;
        for (const config of siteConfigs) {
          if (currentHostname.endsWith(config.hostname)) {
            currentConfig = config;
            break;
          }
        }
        
        // Falls kein Treffer gefunden wurde, prüfe benutzerdefinierte URLs
        if (!currentConfig && settings.customUrls) {
          const matchingCustomUrl = settings.customUrls.find(customUrl => window.location.href.startsWith(customUrl));
          if (matchingCustomUrl) {
            currentConfig = {
              hostname: 'custom',
              usernameIndex: pathParts.length, // Letztes Segment als Benutzername
              excludePatterns: [] // Keine Ausschlüsse
            };
          }
        }
        
        if (!currentConfig) return;
        
        // Prüfe die jeweiligen Toggle-Einstellungen
        if (currentHostname.endsWith("chaturbate.com") && settings.chaturbateEnabled === false) return;
        if ((currentHostname.endsWith("stripchat.com") || currentHostname.endsWith("stripchat.global")) && settings.stripchatEnabled === false) return;
        if (currentHostname.endsWith("xhamsterlive.com") && settings.xhamsterEnabled === false) return;
        if (currentHostname.endsWith("bongacams.com") && settings.bongacamsEnabled === false) return;
        
        if (!shouldShowButton(currentConfig, path)) return;
        
        // Extrahiere den Benutzernamen
        let username;
        if (currentConfig.hostname === 'custom') {
          username = pathParts[pathParts.length - 1];
        } else {
          username = pathParts[currentConfig.usernameIndex - 1];
        }
        if (!username) return;
        
        // Erstelle den Button
        const button = document.createElement('button');
        button.id = 'archivebate-button';
        button.innerHTML = `
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 8px;">
            <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
            <polyline points="15 3 21 3 21 9"></polyline>
            <line x1="10" y1="14" x2="21" y2="3"></line>
          </svg>
          Auf Archivebate öffnen
        `;

        // Style für den Button
        button.style.position = 'fixed';
        button.style.top = '20px';
        button.style.right = '20px';
        button.style.zIndex = '9999';
        button.style.padding = '12px 20px';
        button.style.backgroundColor = '#6a5acd';
        button.style.background = 'linear-gradient(145deg, #6a5acd, #5a4abd)';
        button.style.color = 'white';
        button.style.border = 'none';
        button.style.borderRadius = '8px';
        button.style.cursor = 'pointer';
        button.style.boxShadow = '0 4px 6px rgba(0,0,0,0.1), 0 1px 3px rgba(0,0,0,0.08)';
        button.style.display = 'flex';
        button.style.alignItems = 'center';
        button.style.justifyContent = 'center';
        button.style.fontWeight = '600';
        button.style.transition = 'all 0.3s ease';

        button.addEventListener('mouseenter', () => {
          button.style.transform = 'scale(1.05)';
          button.style.boxShadow = '0 6px 8px rgba(0,0,0,0.15), 0 2px 4px rgba(0,0,0,0.12)';
        });

        button.addEventListener('mouseleave', () => {
          button.style.transform = 'scale(1)';
          button.style.boxShadow = '0 4px 6px rgba(0,0,0,0.1), 0 1px 3px rgba(0,0,0,0.08)';
        });

        button.addEventListener('click', () => {
          window.open(`https://archivebate.com/profile/${username}`, '_blank');
        });

        document.body.appendChild(button);
      }
    );
  }

  // Initialer Button-Check und Beobachtung von URL-Änderungen
  checkAndAddButton();
  observeUrlChanges();
})();