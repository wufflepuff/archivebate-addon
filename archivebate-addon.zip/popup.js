document.addEventListener('DOMContentLoaded', function() {
  // Get references to toggle elements
  const addonToggle = document.getElementById('addonToggle');
  const chaturbateToggle = document.getElementById('chaturbateToggle');
  const stripchatToggle = document.getElementById('stripchatToggle');
  const xhamsterToggle = document.getElementById('xhamsterToggle');
  const bongacamsToggle = document.getElementById('bongacamsToggle');
  
  const customUrlInput = document.getElementById('customUrlInput');
  const addCustomUrlBtn = document.getElementById('addCustomUrlBtn');
  const customUrlList = document.getElementById('customUrlList');

  // Load saved settings
  chrome.storage.sync.get([
    'addonEnabled', 
    'chaturbateEnabled', 
    'stripchatEnabled', 
    'xhamsterEnabled', 
    'bongacamsEnabled',
    'customUrls'
  ], function(result) {
    // Set toggle states
    addonToggle.checked = result.addonEnabled !== false;
    chaturbateToggle.checked = result.chaturbateEnabled !== false;
    stripchatToggle.checked = result.stripchatEnabled !== false;
    xhamsterToggle.checked = result.xhamsterEnabled !== false;
    bongacamsToggle.checked = result.bongacamsEnabled !== false;

    // Populate custom URLs list
    if (result.customUrls) {
      result.customUrls.forEach(url => {
        addCustomUrlToList(url);
      });
    }
  });

  // Save settings when toggles are changed
  function saveToggleSetting(key, value) {
    let setting = {};
    setting[key] = value;
    chrome.storage.sync.set(setting);
  }

  addonToggle.addEventListener('change', function() {
    saveToggleSetting('addonEnabled', this.checked);
  });

  chaturbateToggle.addEventListener('change', function() {
    saveToggleSetting('chaturbateEnabled', this.checked);
  });

  stripchatToggle.addEventListener('change', function() {
    saveToggleSetting('stripchatEnabled', this.checked);
  });

  xhamsterToggle.addEventListener('change', function() {
    saveToggleSetting('xhamsterEnabled', this.checked);
  });

  bongacamsToggle.addEventListener('change', function() {
    saveToggleSetting('bongacamsEnabled', this.checked);
  });

  // Custom URL handling
  addCustomUrlBtn.addEventListener('click', function() {
    const newUrl = customUrlInput.value.trim();
    if (newUrl) {
      // Retrieve existing custom URLs
      chrome.storage.sync.get('customUrls', function(result) {
        const customUrls = result.customUrls || [];
        
        // Add new URL if not already in the list
        if (!customUrls.includes(newUrl)) {
          customUrls.push(newUrl);
          
          // Save updated list
          chrome.storage.sync.set({customUrls: customUrls}, function() {
            addCustomUrlToList(newUrl);
            customUrlInput.value = ''; // Clear input
          });
        }
      });
    }
  });

  // Function to add custom URL to the list
  function addCustomUrlToList(url) {
    const li = document.createElement('li');
    
    // URL text
    const urlSpan = document.createElement('span');
    urlSpan.textContent = url;
    li.appendChild(urlSpan);

    // Remove button
    const removeBtn = document.createElement('button');
    removeBtn.textContent = '×';
    removeBtn.style.marginLeft = '10px';
    removeBtn.addEventListener('click', function() {
      // Remove from storage
      chrome.storage.sync.get('customUrls', function(result) {
        const customUrls = result.customUrls || [];
        const updatedUrls = customUrls.filter(existingUrl => existingUrl !== url);
        
        chrome.storage.sync.set({ customUrls: updatedUrls }, function() {
          li.remove(); // Remove from UI
        });
      });
    });

    li.appendChild(removeBtn);

    // Add to list
    customUrlList.appendChild(li);
  }
});